public class Greeter {

    public static void main(String[] args) {
        System.out.println("Hello world!\n(And all the people of the world)");

    }

}
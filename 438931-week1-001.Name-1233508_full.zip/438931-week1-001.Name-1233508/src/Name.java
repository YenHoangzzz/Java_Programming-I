public class Name {
    
    public static void main(String[] args) {
        System.out.print("Yen Hoang");
        // Please answer to our survey http://oo-start.mooc.fi/english_mooc_participants/new
        // It will take less than 5 minutes!

    }

}